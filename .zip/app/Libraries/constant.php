<?php

define('ACTIVE', 1);
define('UN_ACTIVE', 2);

define('BOOKING_NEW', 1);
define('BOOKING_CONFIRM', 2);
define('BOOKING_COMPLETE', 3);
define('BOOKING_CANCEL', 4);

define('PAYMENT_CASH', 1);
define('PAYMENT_MOMO', 2);

define('PAYMENT_UN_PAID', 0);
define('PAYMENT_PAID', 1);
